
$(document).ready(function(){

var myfbtoken='TOKENID&fields=name,birthday,albums{photos{picture,created_time,album}},cover,picture'
	//me?fields=name,birthday,albums{photos{picture,created_time,album}},cover
			function getfbinfo()
			
			{
				$.ajax('https://graph.facebook.com/me?access_token='+myfbtoken,{
					
					success:function(response){
						console.log(response);
						console.log(typeof(response));
						$("#myemail").text(response.email);
						$("#myprofileid").html('<a target="_blank" href="https://www.facebook.com/'+response.id+'">https://www.facebook.com/'+response.id+'</a>');
						//$("#myhometown").text(response.hometown);
						$("#name").text(response.name);
			
					}
					
					
				}
				);
				
				
			}
$("#fbbutton").on('click',getfbinfo)

});

